from flask import Flask, render_template, request, redirect, session
import snowflake.connector
import uuid
import bcrypt
import random
from config import SNOWFLAKE_CONFIG, SECRET_KEY, OPENAI_API_KEY
from openai import OpenAI
from datetime import datetime, timedelta

# ---------------- SLA CALCULATION ----------------
def calculate_sla(priority):
    now = datetime.utcnow()
    if priority == "High":
        return now + timedelta(hours=4)
    elif priority == "Medium":
        return now + timedelta(hours=8)
    else:
        return now + timedelta(hours=24)

# ---------------- APP INIT ----------------
app = Flask(__name__)
app.secret_key = SECRET_KEY

try:
    client = OpenAI(api_key=OPENAI_API_KEY)
except Exception:
    client = None

def get_connection():
    return snowflake.connector.connect(**SNOWFLAKE_CONFIG)

# ---------------- PASSWORD ----------------
def hash_password(password):
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

def verify_password(password, hashed):
    return bcrypt.checkpw(password.encode(), hashed.encode())

# ---------------- LOGIN ----------------
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        emp_id = request.form['employee_id']
        password = request.form['password']

        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT password_hash, role FROM employees WHERE employee_id=%s", (emp_id,))
        user = cur.fetchone()
        cur.close()
        conn.close()

        if user and verify_password(password, user[0]):
            session['employee_id'] = emp_id
            session['role'] = user[1]

            if user[1] == "manager":
                return redirect('/manager')
            elif user[1] == "team":
                return redirect('/team_dashboard')
            else:
                return redirect('/dashboard')

        return "Invalid Credentials"

    return render_template('login.html')

# ---------------- LOGOUT ----------------
@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

# ---------------- DASHBOARD (Employee) ----------------
@app.route('/dashboard')
def dashboard():
    if 'employee_id' not in session:
        return redirect('/')

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        SELECT t.ticket_id,
               t.issue_type,
               t.priority,
               t.status,
               a.team_id,
               a.assigned_to,
               a.sla_deadline,
               t.resolution
        FROM tickets t
        LEFT JOIN ticket_assignments a
        ON t.ticket_id = a.ticket_id
        WHERE t.employee_id=%s
    """, (session['employee_id'],))

    tickets = cur.fetchall()
    cur.close()
    conn.close()

    return render_template('dashboard.html', tickets=tickets)

# ---------------- TEAM DASHBOARD ----------------
@app.route('/team_dashboard')
def team_dashboard():
    if 'employee_id' not in session or session.get('role') != 'team':
        return redirect('/')

    conn = get_connection()
    cur = conn.cursor()

    # Show tickets assigned to this team member
    cur.execute("""
        SELECT t.ticket_id,
               t.issue_type,
               t.priority,
               t.status,
               a.sla_deadline,
               t.resolution
        FROM tickets t
        JOIN ticket_assignments a
        ON t.ticket_id = a.ticket_id
        WHERE a.assigned_to=%s AND t.status!='Resolved'
    """, (session['employee_id'],))

    tickets = cur.fetchall()
    cur.close()
    conn.close()

    return render_template('team_dashboard.html', tickets=tickets)

# ---------------- CREATE TICKET ----------------
@app.route('/create_ticket', methods=['GET', 'POST'])
def create_ticket():
    if 'employee_id' not in session:
        return redirect('/')

    if request.method == 'POST':
        issue_type = request.form['issue_type']
        description = request.form['description']
        priority = request.form['priority']

        ticket_id = str(uuid.uuid4())[:8]

        conn = get_connection()
        cur = conn.cursor()

        ai_suggestion = "Pending Manager Review"
        status = "Pending Approval"

        cur.execute("""
            INSERT INTO tickets(ticket_id, employee_id, issue_type,
                                description, priority, status, ai_suggestion)
            VALUES (%s,%s,%s,%s,%s,%s,%s)
        """, (ticket_id, session['employee_id'], issue_type,
              description, priority, status, ai_suggestion))

        conn.commit()
        cur.close()
        conn.close()

        return redirect('/dashboard')

    return render_template('create_ticket.html')

# ---------------- MANAGER DASHBOARD ----------------
@app.route('/manager')
def manager():
    if 'employee_id' not in session or session.get('role') != 'manager':
        return redirect('/')

    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT ticket_id, employee_id, issue_type, priority, status
        FROM tickets WHERE status='Pending Approval'
    """)
    tickets = cur.fetchall()
    cur.close()
    conn.close()

    return render_template('manager_dashboard.html', tickets=tickets)

# ---------------- APPROVE & ASSIGN ----------------
@app.route('/approve/<ticket_id>')
def approve(ticket_id):
    if 'employee_id' not in session or session.get('role') != 'manager':
        return redirect('/')

    conn = get_connection()
    cur = conn.cursor()

    cur.execute("SELECT priority, issue_type FROM tickets WHERE ticket_id=%s", (ticket_id,))
    result = cur.fetchone()

    if not result:
        cur.close()
        conn.close()
        return redirect('/manager')

    priority, issue_type = result

    # Map issue type to team
    if issue_type == "Hardware":
        team_id = "IT_HW"
    elif issue_type == "Network":
        team_id = "IT_NET"
    else:
        team_id = "IT_SW"

    # Fetch team members
    cur.execute("SELECT member_id, member_name FROM team_members WHERE team_id=%s", (team_id,))
    members = cur.fetchall()

    if not members:
        cur.close()
        conn.close()
        return "No team members found"

    # Random assignment
    selected_member = random.choice(members)
    member_id, member_name = selected_member

    sla_deadline = calculate_sla(priority)
    assignment_id = str(uuid.uuid4())[:8]

    # Update ticket status
    cur.execute("UPDATE tickets SET status='Assigned' WHERE ticket_id=%s", (ticket_id,))

    # Insert assignment record
    cur.execute("""
        INSERT INTO ticket_assignments
        (assignment_id, ticket_id, team_id, assigned_to,
         assigned_at, sla_deadline)
        VALUES (%s,%s,%s,%s,%s,%s)
    """, (assignment_id, ticket_id, team_id,
          member_name, datetime.utcnow(), sla_deadline))

    conn.commit()
    cur.close()
    conn.close()

    return redirect('/manager')

# ---------------- RESOLVE TICKET ----------------
@app.route('/resolve/<ticket_id>', methods=['POST'])
def resolve(ticket_id):
    if 'employee_id' not in session or session.get('role') != 'team':
        return redirect('/')

    resolution = request.form['resolution']

    conn = get_connection()
    cur = conn.cursor()

    # Update tickets table
    cur.execute("""
        UPDATE tickets
        SET status='Resolved',
            resolution=%s
        WHERE ticket_id=%s
    """, (resolution, ticket_id))

    # Update assignments table
    cur.execute("""
        UPDATE ticket_assignments
        SET resolved_at=%s,
            resolution_notes=%s
        WHERE ticket_id=%s
    """, (datetime.utcnow(), resolution, ticket_id))

    conn.commit()
    cur.close()
    conn.close()

    return redirect('/team_dashboard')

# ---------------- RUN APP ----------------
if __name__ == '__main__':
    app.run(debug=True)