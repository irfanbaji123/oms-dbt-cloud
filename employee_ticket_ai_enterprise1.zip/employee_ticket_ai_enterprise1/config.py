import os

SNOWFLAKE_CONFIG = {
    "user": "BASHA2975",
    "password": "Irf@nb@ji29752975",
    "account": "NRRMYSH-GH03951",
    "warehouse": "COMPUTE_WH",
    "database": "MY_EMPLOYEE",
    "schema": "EMPLOYEE_TICKET",
}

SECRET_KEY = "supersecretkey"
OPENAI_API_KEY = "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"